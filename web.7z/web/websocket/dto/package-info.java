/**
 * Data Access Objects used by WebSocket services.
 */
package com.muka.modul_ubezpieczen.web.websocket.dto;
