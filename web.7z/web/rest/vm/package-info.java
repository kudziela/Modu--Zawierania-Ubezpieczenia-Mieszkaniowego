/**
 * View Models used by Spring MVC REST controllers.
 */
package com.muka.modul_ubezpieczen.web.rest.vm;
