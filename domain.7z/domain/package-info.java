/**
 * JPA domain objects.
 */
package com.muka.modul_ubezpieczen.domain;
