package com.muka.modul_ubezpieczen.domain.Ubezpieczenie;

/**
 * Created by Magda on 17.12.2017.
 */
public enum TypUbezpieczenia {

    UBEZPIECZENIE_MIESZKANIOWE, UBEZPIECZENIE_RUCHOMOSCI_DOMOWYCH, ZABEZPIECZENIE_PRZECIWKRADZIEZOWE;
}
